from datetime import datetime
from datetime import timedelta
from botocore.exceptions import ClientError
def lambda_handler(event, context):
    # TODO implement
    import boto3

    accountnumber=boto3.client('sts').get_caller_identity()['Account']
    regions=['us-east-1']
    
    
    eventslist = ['test-ctrail-state-change', 'event2', 'event3']
    
    
    for region in regions:
        client = boto3.client('events', region_name=region)
        
        response = client.list_rules()
        for event in response['Rules']:
            eventname = event['Name']
            eventstate= event['State']
            
            if (eventstate == 'DISABLED') and (eventname in eventslist):
                ctclient = boto3.client('cloudtrail', region_name=region)
                ctresponse = ctclient.lookup_events(
                    LookupAttributes=[
                        {
                            'AttributeKey': 'EventName',
                            'AttributeValue': 'DisableRule'
                        },
                    ],
                    StartTime=datetime.now() - timedelta(days=200),
                    EndTime=datetime.now(),
                    
                )
                username='usernamenotfound'
                print ctresponse
                if ctresponse.has_key('Events'):
                    username =ctresponse['Events'][0]['Username']
                # print username
                
                
                # enable the rule
                eventresponse = client.enable_rule(
                    Name=eventname
                )


                snsclient = boto3.client('sns')
                
                response = snsclient.publish(
                    TopicArn='arn:aws:sns:us-east-1:412601977023:rule',
                    Message="Cloudwatch Event named %s was disabled by %s in %s region. Account number %s . Event enabled now" % (eventname, username, region, accountnumber),
                    Subject='Cloudwatch Event:  '+eventname+ ' disabled',
                    
                )
                
                
    
    
    
    return 'Hello from Lambda'
